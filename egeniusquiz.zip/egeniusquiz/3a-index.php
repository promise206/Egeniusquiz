<!DOCTYYPE html>
<html>
  <head>
    <title>
      Comments Example Page
    </title>
    <script src="public/3b-comments.js"></script>
    <link href="public/3c-comments.css" rel="stylesheet">
  </head>
  <body>
    <p>Hello world! This is a comments demo.</p>
    <p>This should be your blog post, product page, or whichever that you want to add comments.</p>

    <!-- GIVE YOUR PAGE OR PRODUCT A POST ID -->
    <input type="hidden" id="post_id" value="999"/>

    <!-- CREATE A CONTAINER TO LOAD COMMENTS -->
    <div id="comments"></div>

    <!-- CREATE A CONTAINER TO LOAD REPLY DOCKET -->
    <div id="reply-main"></div>
  </body>
</html>