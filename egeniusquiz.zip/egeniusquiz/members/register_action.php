<?php
include('user.class.php');
$account=new user();


global $con;
if (isset($_POST['register'])) {
	$firstname = $_POST['m_firstname'];
	$lastname = $_POST['m_lastname'];
	$email = $_POST['m_email'];
	$address = $_POST['m_address'];
	$mobile = $_POST['m_mobile'];
	$pass = $_POST['m_pass'];
	$confirm_pass = $_POST['pass_again'];
	$dob = $_POST['m_date'];
	$gender = $_POST['m_gender'];
    $favorite_food = $_POST['secret_question'];
	$m_image = $_FILES['m_image']['name'];
	$m_image_tmp = $_FILES['m_image']['tmp_name'];
    $m_image_size = $_FILES['m_image']['size'];
    $max_image_size = 2097152;
    $m_image_type = strtolower($_FILES['m_image']['type']);
    $state = $_POST['m_state'];
	$ip = $_SERVER['REMOTE_ADDR']?:($_SERVER['HTTP_X_FORWARDED_FOR']?:$_SERVER['HTTP_CLINT_IP']);
	$extension = strtolower(substr($m_image, strpos($m_image, '.')+1));
	

	$firstname = stripslashes($firstname);
	$firstname = addslashes($firstname);
	$firstname = ucwords(strtolower($firstname));
	$lastname = stripslashes($lastname);
	$lastname = addslashes($lastname);
	$lastname = ucwords(strtolower($lastname));
	$email = stripslashes($email);
	$email = addslashes($email);
	$address = stripslashes($address);
	$address = addslashes($address);
	$address = ucwords(strtolower($address));
	$mobile = stripslashes($mobile);
	$mobile = addslashes($mobile);
	$gender = stripslashes($gender);
	$gender = addslashes($gender);
	$sid=uniqid();
    $date=date("Y-m-d");
	
	
	$dob = stripslashes($dob);
	$dob = addslashes($dob);
	$state = stripslashes($state);
	$state = addslashes($state);

	$password = stripslashes($pass);
	$password = addslashes($password);
	$password = md5($password);

	$insert_user = array(

	'first_name' => mysqli_real_escape_string($account->get_conn(), $firstname),
	'last_name' => mysqli_real_escape_string($account->get_conn(), $lastname),
	'address' => mysqli_real_escape_string($account->get_conn(), $address),
	'email' => mysqli_real_escape_string($account->get_conn(), $email),
	'mobile' => mysqli_real_escape_string($account->get_conn(), $mobile),
	'password' => mysqli_real_escape_string($account->get_conn(), $password),
	'dob' => mysqli_real_escape_string($account->get_conn(), $dob),
    'gender' => mysqli_real_escape_string($account->get_conn(), $gender),
    'm_image' => mysqli_real_escape_string($account->get_conn(), $m_image),
    'state' => mysqli_real_escape_string($account->get_conn(), $state),
    'secret_question' => mysqli_real_escape_string($account->get_conn(), $favorite_food),
	'm_ip' => mysqli_real_escape_string($account->get_conn(), $ip)
	
	);

	$insert_airtime = array(

		'firstname' => mysqli_real_escape_string($account->get_conn(), $firstname),
		'lastname' => mysqli_real_escape_string($account->get_conn(), $lastname),
		'email' => mysqli_real_escape_string($account->get_conn(), $email),
		'subid' => mysqli_real_escape_string($account->get_conn(), $sid),
		'mobile' => mysqli_real_escape_string($account->get_conn(), $mobile),
		'regdate' => mysqli_real_escape_string($account->get_conn(), $date),
		
		);
	
	if(!$firstname == '' && !$firstname == '' && !$dob == '' && !$email == '' && !$password == '' && !$confirm_pass == '' && !$mobile == '' && !$address == '' && !$favorite_food == ''){


		$sel_user = "select * from user where email = '$email' ";

        $run_user = mysqli_query($account->get_conn(), $sel_user);


        $check_user = mysqli_num_rows($run_user);

        if($check_user>0) {

          echo "<script>alert('email already exist!')</script>";
          echo "<script>window.open('register.php','_self')</script>";
          exit();
		}
		
		$sel_mobile = "SELECT * FROM user WHERE mobile = '$mobile' ";

        $run_mobile = mysqli_query($account->get_conn(), $sel_mobile);


        $check_mobile = mysqli_num_rows($run_mobile);

        if($check_mobile>0) {

          echo "<script>alert('Phone Number Already Exist!')</script>";
          echo "<script>window.open('register.php','_self')</script>";
          exit();
        }

		if($pass == $confirm_pass){
			//QUERIES
			if (($extension=='jpg' || $extension=='jpeg' || $extension=='png'|| $extension=='' ) && ($m_image_type=='image/png' || $m_image_type=='image/jpeg' || $m_image_type=='image/jpg'|| $m_image_type=='' )) {
				
				if ($account->register("user", $insert_user)) {
					if($account->register("freeairtime", $insert_airtime)){
					
						//insert mobile into user mobile file
						$value= $mobile.',';
						$file_name1= '../admin/users_mobiles.txt';
						file_put_contents($file_name1, $value, FILE_APPEND | LOCK_EX);

						$file_name2= '../admin/freeairtime_mobiles.txt';
          				file_put_contents($file_name2, $value, FILE_APPEND | LOCK_EX);

						move_uploaded_file($m_image_tmp,"images/$m_image");
						$success_message = 'Account Registered';
						header('Location: login.php?message='. $success_message);
					}
				}
				
			}else{
				echo "<script>alert('Image File Not Supported!')</script>";
				echo "<script>window.open('register.php','_self')</script>";
            
			}
		}
		else {
			echo '<p class="required">Password mismatch!</p>';
			echo "<script>window.open('register.php','_self')</script>";
          
		}
	}else {
		echo '<p class="required">All Fields are Required!</p>';
	}
}

?>