<!--Banner-->
<div class="banner">
    <div class="bg-color">
      <div class="container">
        <div class="row">
          <div class="banner-text text-center">
            <div class="text-border">
              <h2 class="text-dec">Trust & Quality</h2>
            </div>
            <div class="intro-para text-center quote">
              <p class="big-text">Exam Preparatory Quiz</p>
              <p class="small-text">This Platform is Meant to Accelerate your Learning, Do you know you can win Airtime by answering our questions correctly?</p>
              <a href="quizwinner.php" class="btn get-quote">VIEW QUIZ WINNERS</a>
            </div>
            <a href="#courses" class="mouse-hover">
              <div class="mouse"></div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--/ Banner-->