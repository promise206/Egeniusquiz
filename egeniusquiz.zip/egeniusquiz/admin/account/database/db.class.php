<?php

$con = mysqli_connect("localhost","egenujyx_jaspino206","Promsy_205$","egenujyx_egeniusquiz");


?>