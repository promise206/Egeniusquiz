<?php

$con = mysqli_connect("localhost","root","","egenujyx_egeniusquiz");


?>