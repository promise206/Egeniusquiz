
<!-- Reset Rank Starts-->
<?php
if (isset($_GET['resetrank'])) {

    echo '<form action="" method="post" enctype="multipart/form-data">
<div class="row">
  <div class="col-md-6 padding-top-10">
    <label for="m_gender" class="control-label" style="color: red;">Do You Really Want To Delete All Data in the Rank?</label><br>
    <button type="submit" name="yes" class="btn btn-danger">Yes,i do</button>
    <button type="submit" name="no" class="btn btn-success">No,just joking</button>
  </div>
</div>
</form>';
 
  if (isset($_POST['yes'])) {

    $reset_rank = "DELETE FROM `rank`";
    $run_reset = mysqli_query($con,$reset_rank);
    $reset_history = "DELETE FROM `history`";
    $run_history = mysqli_query($con,$reset_history);
    echo "<script>alert('Rank Has Been Reset!')</script>";
    echo"<script>window.open('dash.php?q=2','_self')</script>";
      exit();
  }
  if (isset($_POST['no'])) {
    echo "<script>alert('Do Not Joke Again!')</script>";
        echo"<script>window.open('dash.php?q=2','_self')</script>";
      exit();
  }
  }
?>
<!-- Reset Rank Ends-->


<!-- Reset WaecQuiz Starts-->
<?php
if (isset($_GET['resetprofquiz'])) {

    echo '<form action="" method="post" enctype="multipart/form-data">
<div class="row">
  <div class="col-md-6 padding-top-10">
    <label for="m_gender" class="control-label" style="color: red;">Do You Really Want To Delete All Data in ProfQuiz?</label><br>
    <button type="submit" name="yes" class="btn btn-danger">Yes,i do</button>
    <button type="submit" name="no" class="btn btn-success">No,just joking</button>
  </div>
</div>
</form>';
 
  if (isset($_POST['yes'])) {

    $reset_rank = "DELETE FROM `profquiz`";
    $run_reset = mysqli_query($con,$reset_rank);
    echo "<script>alert('Data Has Been Reset!')</script>";
    echo"<script>window.open('dash.php?q=11','_self')</script>";
      exit();
  }
  if (isset($_POST['no'])) {
    echo "<script>alert('Do Not Joke Again!')</script>";
        echo"<script>window.open('dash.php?q=11','_self')</script>";
      exit();
  }
  }
?>
<!-- Reset WaecQuiz Ends-->

<!-- Reset JambQuiz Starts-->
<?php
if (isset($_GET['resetjambquiz'])) {

    echo '<form action="" method="post" enctype="multipart/form-data">
<div class="row">
  <div class="col-md-6 padding-top-10">
    <label for="m_gender" class="control-label" style="color: red;">Do You Really Want To Delete All Data in LegendQuiz?</label><br>
    <button type="submit" name="yes" class="btn btn-danger">Yes,i do</button>
    <button type="submit" name="no" class="btn btn-success">No,just joking</button>
  </div>
</div>
</form>';
 
  if (isset($_POST['yes'])) {

    $reset_rank = "DELETE FROM `legendquiz`";
    $run_reset = mysqli_query($con,$reset_rank);
    echo "<script>alert('Data Has Been Reset!')</script>";
    echo"<script>window.open('dash.php?q=19','_self')</script>";
      exit();
  }
  if (isset($_POST['no'])) {
    echo "<script>alert('Do Not Joke Again!')</script>";
        echo"<script>window.open('dash.php?q=19','_self')</script>";
      exit();
  }
  }
?>
<!-- Reset JambQuiz Ends-->

<!-- Reset AirtimeQuiz Starts-->
<?php
if (isset($_GET['resetairtimequiz'])) {

    echo '<form action="" method="post" enctype="multipart/form-data">
<div class="row">
  <div class="col-md-6 padding-top-10">
    <label for="m_gender" class="control-label" style="color: red;">Do You Really Want To Delete All Data in Free Airtime Quiz?</label><br>
    <button type="submit" name="yes" class="btn btn-danger">Yes,i do</button>
    <button type="submit" name="no" class="btn btn-success">No,just joking</button>
  </div>
</div>
</form>';
 
  if (isset($_POST['yes'])) {

    $reset_rank = "DELETE FROM `freeairtime`";
    $run_reset = mysqli_query($con,$reset_rank);
    echo "<script>alert('Data Has Been Reset!')</script>";
    echo"<script>window.open('dash.php?q=13','_self')</script>";
      exit();
  }
  if (isset($_POST['no'])) {
    echo "<script>alert('Do Not Joke Again!')</script>";
        echo"<script>window.open('dash.php?q=13','_self')</script>";
      exit();
  }
  }
?>
<!-- Reset AirtimeQuiz Ends-->